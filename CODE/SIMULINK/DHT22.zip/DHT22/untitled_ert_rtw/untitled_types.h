/*
 * File: untitled_types.h
 *
 * Code generated for Simulink model 'untitled'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Thu Nov  6 01:43:56 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef untitled_types_h_
#define untitled_types_h_
#include "rtwtypes.h"
#ifndef struct_tag_XOjuL5IegWWhjS13qEHVB
#define struct_tag_XOjuL5IegWWhjS13qEHVB

struct tag_XOjuL5IegWWhjS13qEHVB
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real_T SampleTime;
  uint32_T dataDelay;
};

#endif                                 /* struct_tag_XOjuL5IegWWhjS13qEHVB */

#ifndef typedef_DHT22_untitled_T
#define typedef_DHT22_untitled_T

typedef struct tag_XOjuL5IegWWhjS13qEHVB DHT22_untitled_T;

#endif                                 /* typedef_DHT22_untitled_T */

/* Parameters (default storage) */
typedef struct P_untitled_T_ P_untitled_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_untitled_T RT_MODEL_untitled_T;

#endif                                 /* untitled_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
