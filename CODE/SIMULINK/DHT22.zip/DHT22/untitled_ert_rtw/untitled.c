/*
 * File: untitled.c
 *
 * Code generated for Simulink model 'untitled'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Thu Nov  6 01:43:56 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "untitled.h"
#include "untitled_private.h"

/* Block signals (default storage) */
B_untitled_T untitled_B;

/* Block states (default storage) */
DW_untitled_T untitled_DW;

/* Real-time model */
static RT_MODEL_untitled_T untitled_M_;
RT_MODEL_untitled_T *const untitled_M = &untitled_M_;

/* Model step function */
void untitled_step(void)
{
  /* MATLABSystem: '<Root>/MATLAB System' */
  if (untitled_DW.obj.dataDelay != untitled_P.MATLABSystem_dataDelay) {
    untitled_DW.obj.dataDelay = untitled_P.MATLABSystem_dataDelay;
  }

  if (untitled_DW.obj.SampleTime != untitled_P.MATLABSystem_SampleTime) {
    untitled_DW.obj.SampleTime = untitled_P.MATLABSystem_SampleTime;
  }

  /* MATLABSystem: '<Root>/MATLAB System' */
  /*         %% Define output properties */
  untitled_B.MATLABSystem_o1 = 0.0F;

  /* MATLABSystem: '<Root>/MATLAB System' */
  untitled_B.MATLABSystem_o2 = 0.0F;
  stepFunctionDHT22(&untitled_B.MATLABSystem_o1, 1.0,
                    &untitled_B.MATLABSystem_o2, 1.0, &untitled_DW.obj.dataDelay,
                    1.0);

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.2, which is the step size
   * of the task. Size of "clockTick0" ensures timer will not overflow during the
   * application lifespan selected.
   */
  untitled_M->Timing.clockTick0++;
}

/* Model initialize function */
void untitled_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(untitled_M, -1);

  /* External mode info */
  untitled_M->Sizes.checksums[0] = (170830230U);
  untitled_M->Sizes.checksums[1] = (3901488260U);
  untitled_M->Sizes.checksums[2] = (1322136061U);
  untitled_M->Sizes.checksums[3] = (309400406U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    untitled_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(untitled_M->extModeInfo,
      &untitled_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(untitled_M->extModeInfo, untitled_M->Sizes.checksums);
    rteiSetTFinalTicks(untitled_M->extModeInfo, -1);
  }

  /* Start for MATLABSystem: '<Root>/MATLAB System' */
  /*  Constructor */
  untitled_DW.obj.matlabCodegenIsDeleted = false;
  untitled_DW.obj.dataDelay = untitled_P.MATLABSystem_dataDelay;
  untitled_DW.obj.SampleTime = untitled_P.MATLABSystem_SampleTime;
  untitled_DW.obj.isSetupComplete = false;
  untitled_DW.obj.isInitialized = 1L;

  /*         %% Define output properties */
  /*   Check the input size */
  setupFunctionDHT22(&untitled_DW.obj.dataDelay, 1.0);
  untitled_DW.obj.isSetupComplete = true;
}

/* Model terminate function */
void untitled_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/MATLAB System' */
  if (!untitled_DW.obj.matlabCodegenIsDeleted) {
    untitled_DW.obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/MATLAB System' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
