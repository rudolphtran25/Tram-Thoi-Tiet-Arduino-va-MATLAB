#include "DHT22.h"
#include "arduino.h"
#include "Adafruit_Sensor.h"
#include "DHT.h"
#include "DHT_U.h"

#define DHTPIN A3
#define DHTTYPE DHT22
DHT_Unified dht(DHTPIN, DHTTYPE);
uint32_t delayMS;

// dataDelay uint32 [1,1] Tunable

void setupFunctionDHT22(uint32_T * dataDelay,int size_vector__1){
    Serial.begin(9600);
    dht.begin();
    delayMS = *dataDelay;
}

// NhietDo single [1,1]
// DoAm single [1,1]


void stepFunctionDHT22(float * NhietDo,int size_vector_1,float * DoAm,int size_vector_2, uint32_T * dataDelay,int size_vector__1){
  delay(delayMS);
    sensors_event_t event;
    dht.temperature().getEvent(&event);
    if (isnan(event.temperature)) {
    }
    else {
        *NhietDo = event.temperature;
    }
    dht.humidity().getEvent(&event);
    if (isnan(event.relative_humidity)) {
    }
    else {
        *DoAm = event.relative_humidity;
    }
}