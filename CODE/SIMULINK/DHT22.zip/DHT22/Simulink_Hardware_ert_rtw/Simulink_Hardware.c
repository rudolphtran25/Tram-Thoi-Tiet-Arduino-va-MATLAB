/*
 * File: Simulink_Hardware.c
 *
 * Code generated for Simulink model 'Simulink_Hardware'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Thu Nov  6 16:01:43 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Simulink_Hardware.h"
#include "Simulink_Hardware_private.h"

/* Block signals (default storage) */
B_Simulink_Hardware_T Simulink_Hardware_B;

/* Block states (default storage) */
DW_Simulink_Hardware_T Simulink_Hardware_DW;

/* Real-time model */
static RT_MODEL_Simulink_Hardware_T Simulink_Hardware_M_;
RT_MODEL_Simulink_Hardware_T *const Simulink_Hardware_M = &Simulink_Hardware_M_;

/* Model step function */
void Simulink_Hardware_step(void)
{
  /* MATLABSystem: '<Root>/MATLAB System' */
  if (Simulink_Hardware_DW.obj.dataDelay !=
      Simulink_Hardware_P.MATLABSystem_dataDelay) {
    Simulink_Hardware_DW.obj.dataDelay =
      Simulink_Hardware_P.MATLABSystem_dataDelay;
  }

  if (Simulink_Hardware_DW.obj.SampleTime !=
      Simulink_Hardware_P.MATLABSystem_SampleTime) {
    Simulink_Hardware_DW.obj.SampleTime =
      Simulink_Hardware_P.MATLABSystem_SampleTime;
  }

  /* MATLABSystem: '<Root>/MATLAB System' */
  /*         %% Define output properties */
  Simulink_Hardware_B.MATLABSystem_o1 = 0.0F;

  /* MATLABSystem: '<Root>/MATLAB System' */
  Simulink_Hardware_B.MATLABSystem_o2 = 0.0F;
  stepFunctionDHT22(&Simulink_Hardware_B.MATLABSystem_o1, 1.0,
                    &Simulink_Hardware_B.MATLABSystem_o2, 1.0,
                    &Simulink_Hardware_DW.obj.dataDelay, 1.0);

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.2, which is the step size
   * of the task. Size of "clockTick0" ensures timer will not overflow during the
   * application lifespan selected.
   */
  Simulink_Hardware_M->Timing.clockTick0++;
}

/* Model initialize function */
void Simulink_Hardware_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(Simulink_Hardware_M, -1);

  /* External mode info */
  Simulink_Hardware_M->Sizes.checksums[0] = (3930420723U);
  Simulink_Hardware_M->Sizes.checksums[1] = (377582248U);
  Simulink_Hardware_M->Sizes.checksums[2] = (3958809031U);
  Simulink_Hardware_M->Sizes.checksums[3] = (1230078810U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    Simulink_Hardware_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Simulink_Hardware_M->extModeInfo,
      &Simulink_Hardware_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Simulink_Hardware_M->extModeInfo,
                        Simulink_Hardware_M->Sizes.checksums);
    rteiSetTFinalTicks(Simulink_Hardware_M->extModeInfo, -1);
  }

  /* Start for MATLABSystem: '<Root>/MATLAB System' */
  /*  Constructor */
  Simulink_Hardware_DW.obj.matlabCodegenIsDeleted = false;
  Simulink_Hardware_DW.obj.dataDelay =
    Simulink_Hardware_P.MATLABSystem_dataDelay;
  Simulink_Hardware_DW.obj.SampleTime =
    Simulink_Hardware_P.MATLABSystem_SampleTime;
  Simulink_Hardware_DW.obj.isSetupComplete = false;
  Simulink_Hardware_DW.obj.isInitialized = 1L;

  /*         %% Define output properties */
  /*   Check the input size */
  setupFunctionDHT22(&Simulink_Hardware_DW.obj.dataDelay, 1.0);
  Simulink_Hardware_DW.obj.isSetupComplete = true;
}

/* Model terminate function */
void Simulink_Hardware_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/MATLAB System' */
  if (!Simulink_Hardware_DW.obj.matlabCodegenIsDeleted) {
    Simulink_Hardware_DW.obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<Root>/MATLAB System' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
