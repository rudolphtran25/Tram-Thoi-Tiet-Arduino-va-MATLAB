/*
 * File: Simulink_Hardware_private.h
 *
 * Code generated for Simulink model 'Simulink_Hardware'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Thu Nov  6 16:01:43 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Simulink_Hardware_private_h_
#define Simulink_Hardware_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "Simulink_Hardware_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif
#endif                                 /* Simulink_Hardware_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
