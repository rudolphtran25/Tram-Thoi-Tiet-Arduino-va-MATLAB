/*
 * File: Simulink_Hardware_types.h
 *
 * Code generated for Simulink model 'Simulink_Hardware'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Thu Nov  6 16:01:43 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Simulink_Hardware_types_h_
#define Simulink_Hardware_types_h_
#include "rtwtypes.h"
#ifndef struct_tag_XOjuL5IegWWhjS13qEHVB
#define struct_tag_XOjuL5IegWWhjS13qEHVB

struct tag_XOjuL5IegWWhjS13qEHVB
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real_T SampleTime;
  uint32_T dataDelay;
};

#endif                                 /* struct_tag_XOjuL5IegWWhjS13qEHVB */

#ifndef typedef_DHT22_Simulink_Hardware_T
#define typedef_DHT22_Simulink_Hardware_T

typedef struct tag_XOjuL5IegWWhjS13qEHVB DHT22_Simulink_Hardware_T;

#endif                                 /* typedef_DHT22_Simulink_Hardware_T */

/* Parameters (default storage) */
typedef struct P_Simulink_Hardware_T_ P_Simulink_Hardware_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Simulink_Hardware_T RT_MODEL_Simulink_Hardware_T;

#endif                                 /* Simulink_Hardware_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
