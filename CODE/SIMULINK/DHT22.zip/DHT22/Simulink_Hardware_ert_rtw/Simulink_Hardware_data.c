/*
 * File: Simulink_Hardware_data.c
 *
 * Code generated for Simulink model 'Simulink_Hardware'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 25.1 (R2025a) 21-Nov-2024
 * C/C++ source code generated on : Thu Nov  6 16:01:43 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Simulink_Hardware.h"

/* Block parameters (default storage) */
P_Simulink_Hardware_T Simulink_Hardware_P = {
  /* Expression: -1
   * Referenced by: '<Root>/MATLAB System'
   */
  -1.0,

  /* Expression: uint32( 1 )
   * Referenced by: '<Root>/MATLAB System'
   */
  1UL
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
